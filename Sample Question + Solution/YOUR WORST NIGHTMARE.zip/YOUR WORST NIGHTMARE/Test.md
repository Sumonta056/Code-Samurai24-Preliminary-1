get

http://localhost:5000/api/books


post 

http://localhost:5000/api/books

{
 "id": 2,
 "title": "Shash Bela",
 "author": "Harper Lee",
 "genre": "Fiction",
 "price": 19.99
}
